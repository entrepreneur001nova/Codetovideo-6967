(() => {
"use strict";
const W=1920,H=1080,DURATION=268.167,SCENE_COUNT=32,SCENE_LEN=DURATION/SCENE_COUNT;
const canvas=document.getElementById("stage"),ctx=canvas.getContext("2d");
const audio=document.getElementById("audio"),seek=document.getElementById("seek");
const sceneLabel=document.getElementById("sceneLabel"),timeLabel=document.getElementById("timeLabel");
const sceneList=document.getElementById("sceneList");
let audioCtx=null, analyser=null, source=null, freqData=null, raf=0, recording=false, recorder=null, chunks=[];
const scenes=[
 ["Moonlit rooftops","Establish the magical city; the girl looks up as lanterns wake."],
 ["A sky full of wishes","She steps onto a terrace; fireflies drift around her."],
 ["The glowing moon","A smiling moon rises behind the skyline; the girl waves."],
 ["First spark","A small sparkler blooms above her hand; warm light flickers."],
 ["Petal breeze","Pink petals cross the frame as she turns in a gentle dance."],
 ["Lantern river","Paper lanterns float upward; camera slowly pushes in."],
 ["Temple bells","Decorative bells sway; windows glow in a rhythmic pattern."],
 ["Starry courtyard","The girl spins once; her scarf follows with a soft arc."],
 ["Cloud passage","Lavender clouds drift past the moon; stars twinkle."],
 ["Rooftop dance","A wider dance phrase with two side steps and a turn."],
 ["Firefly constellation","Fireflies trace a dotted circle around the character."],
 ["Golden skyline","The city lights brighten in layers from left to right."],
 ["Moonlit bridge","She walks across a small bridge above the rooftops."],
 ["Floating diyas","Little lamps drift across a calm blue foreground."],
 ["Kite in the night","A tiny decorative kite glides across the sky."],
 ["Festival rooftops","More windows and hanging lights appear; gentle camera pan."],
 ["Quiet close-up","A warm close view; she blinks and smiles softly."],
 ["Petal spiral","Petals spiral upward into a loose heart-like swirl."],
 ["Night garden","Stylized flowers open one by one around the terrace."],
 ["Saffron clouds","The sky shifts toward deep indigo and saffron at the horizon."],
 ["A circle of light","A dotted halo forms behind the girl, then dissolves."],
 ["The little procession","Lanterns pass in the distance; she waves toward them."],
 ["Firework flowers","Small non-explosive sparkler-like starbursts bloom overhead."],
 ["A gentle refrain","She repeats a simple two-step dance as the city glows."],
 ["The moon descends","The moon slips behind a cloud; stars become brighter."],
 ["Dawn-coloured glow","The horizon warms slightly while the sky remains purple."],
 ["One last dance","A final graceful turn; scarf and skirt follow through."],
 ["Lights in every window","Building lights pulse softly in staggered groups."],
 ["A sky of petals","A soft petal shower fills the foreground."],
 ["The city watches","Wide skyline composition; girl stands centered on terrace."],
 ["Lantern farewell","Lanterns rise and fade into the star field."],
 ["Last sparkle","The girl waves; one star glows, then the scene gently fades."]
];
const palette=["#21123d","#291443","#24133e","#321747","#24133c","#2c1743","#1e153c","#301744"];
const stars=Array.from({length:120},(_,i)=>({x:(i*7919%1920),y:(i*3571%700),r:1+(i%4)*.65,p:i*.71}));
const buildings=Array.from({length:19},(_,i)=>({x:i*108-30,w:88+(i%3)*22,h:170+(i*73%210),c:i%2?"#39204b":"#302044",roof:i%3}));
const particles=Array.from({length:80},(_,i)=>({x:(i*313%1920),y:(i*191%1080),s:2+(i%4),v:.25+(i%5)*.12,p:i*1.9}));

function clamp(v,a,b){return Math.max(a,Math.min(b,v))}
function mix(a,b,t){return a+(b-a)*t}
function roundedRect(x,y,w,h,r,fill,stroke){ctx.beginPath();ctx.roundRect(x,y,w,h,r);ctx.fillStyle=fill;ctx.fill();if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=5;ctx.stroke();}}
function glow(x,y,r,color,alpha=1){ctx.save();ctx.globalAlpha=alpha;ctx.shadowColor=color;ctx.shadowBlur=r*.65;ctx.fillStyle=color;ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx.fill();ctx.restore();}
function text(str,x,y,size,color,align="center"){ctx.save();ctx.font=`700 ${size}px Georgia, serif`;ctx.textAlign=align;ctx.fillStyle=color;ctx.shadowColor="#12091f";ctx.shadowBlur=12;ctx.fillText(str,x,y);ctx.restore();}

function drawSky(t,scene,energy){
 const base=palette[scene%palette.length];
 const g=ctx.createLinearGradient(0,0,0,H);g.addColorStop(0,base);g.addColorStop(.7,"#39204f");g.addColorStop(1,"#8a4960");
 ctx.fillStyle=g;ctx.fillRect(0,0,W,H);
 // soft cloud bands
 ctx.save();ctx.globalAlpha=.12;
 for(let i=0;i<5;i++){let x=((i*510+t*10)%2300)-250;ctx.fillStyle=i%2?"#d99a9b":"#9a83c5";ctx.beginPath();ctx.ellipse(x,170+i*90,260,35,0,0,Math.PI*2);ctx.fill();}
 ctx.restore();
 // moon
 let mx=1450+Math.sin(t*.08)*35,my=220+Math.sin(t*.13)*12;
 glow(mx,my,116,"#ffe4a1",.15);ctx.fillStyle="#ffe8b0";ctx.beginPath();ctx.arc(mx,my,100,0,Math.PI*2);ctx.fill();
 ctx.fillStyle="#f7cf91";ctx.globalAlpha=.5;
 [[-35,-15,12],[28,23,9],[43,-38,7]].forEach(a=>{ctx.beginPath();ctx.arc(mx+a[0],my+a[1],a[2],0,Math.PI*2);ctx.fill()});ctx.globalAlpha=1;
 // stars
 stars.forEach(s=>{let a=.35+.55*(.5+.5*Math.sin(t*1.8+s.p));glow(s.x,s.y,s.r*(1+energy*.8),"#fff0c7",a)});
 // floating particles
 particles.forEach(p=>{let x=(p.x+t*18*p.v)%W,y=(p.y-t*13*p.v+H)%H;glow(x,y,p.s,"#ffd58c",.38+.25*Math.sin(t+p.p))});
}

function drawCity(t,scene,energy){
 // distant silhouette
 ctx.fillStyle="#21162f";ctx.beginPath();ctx.moveTo(0,770);
 for(let i=0;i<=W;i+=80){ctx.lineTo(i,760-(i*17%100));ctx.lineTo(i+40,760-(i*23%140));}
 ctx.lineTo(W,H);ctx.lineTo(0,H);ctx.fill();
 buildings.forEach((b,i)=>{
  let y=850-b.h;ctx.fillStyle=b.c;ctx.fillRect(b.x,y,b.w,b.h+260);
  ctx.strokeStyle="#d48b68";ctx.lineWidth=5;ctx.beginPath();ctx.moveTo(b.x,y);ctx.lineTo(b.x+b.w/2,y-24-(b.roof*8));ctx.lineTo(b.x+b.w,y);ctx.stroke();
  for(let wy=y+45;wy<1020;wy+=55)for(let wx=b.x+17;wx<b.x+b.w-8;wx+=34){
   let on=Math.sin(t*1.8+i*2+wx)>.05;ctx.fillStyle=on?"#ffc66e":"#76506a";roundedRect(wx,wy,17,27,5,ctx.fillStyle);
  }
  // roof lamps
  if(i%2===0){glow(b.x+b.w/2,y-28,7,"#ffcf80",.8)}
 });
 // terrace foreground
 ctx.fillStyle="#21152f";ctx.fillRect(0,1000,W,80);
 ctx.fillStyle="#d48b68";ctx.fillRect(0,995,W,7);
 for(let x=0;x<W;x+=80){ctx.fillStyle="#e9ad72";ctx.fillRect(x,1010,4,70)}
}

function drawGirl(t,scene,energy){
 const beat=Math.sin(t*6.2), bob=Math.sin(t*3.1)*10+beat*3;
 const x=930+Math.sin(t*.55)*28, y=720+bob;
 ctx.save();ctx.translate(x,y);
 // shadow
 ctx.fillStyle="#130c24";ctx.globalAlpha=.45;ctx.beginPath();ctx.ellipse(0,270,130,24,0,0,Math.PI*2);ctx.fill();ctx.globalAlpha=1;
 // scarf flowing behind
 ctx.strokeStyle="#e95b7d";ctx.lineWidth=25;ctx.lineCap="round";ctx.beginPath();ctx.moveTo(-45,-70);ctx.quadraticCurveTo(-185,-130+Math.sin(t*2)*25,-210,-45+Math.sin(t*2)*45);ctx.stroke();
 ctx.strokeStyle="#ffc46e";ctx.lineWidth=5;ctx.beginPath();ctx.moveTo(-55,-70);ctx.quadraticCurveTo(-185,-130+Math.sin(t*2)*25,-210,-45+Math.sin(t*2)*45);ctx.stroke();
 // skirt
 ctx.fillStyle="#e83e77";ctx.strokeStyle="#f9c66f";ctx.lineWidth=8;ctx.beginPath();ctx.moveTo(-55,35);ctx.quadraticCurveTo(-95,155,-140,250);ctx.quadraticCurveTo(0,290,140,250);ctx.quadraticCurveTo(95,155,55,35);ctx.closePath();ctx.fill();ctx.stroke();
 ctx.fillStyle="#ffb94f";ctx.fillRect(-100,218,200,9);
 // blouse/body
 roundedRect(-58,-75,116,135,28,"#16a69b","#4a2445");
 // arms, alternate dance
 const arm=Math.sin(t*2.4+scene)*.55;
 ctx.strokeStyle="#b96a4d";ctx.lineWidth=24;ctx.lineCap="round";
 ctx.beginPath();ctx.moveTo(-48,-45);ctx.quadraticCurveTo(-105,-20-45*arm,-105,-100-35*arm);ctx.stroke();
 ctx.beginPath();ctx.moveTo(48,-45);ctx.quadraticCurveTo(105,-5+45*arm,105,-120+30*arm);ctx.stroke();
 // bangles
 ctx.strokeStyle="#ffd16f";ctx.lineWidth=8;ctx.beginPath();ctx.arc(-105,-90-35*arm,17,-1,1);ctx.stroke();ctx.beginPath();ctx.arc(105,-110+30*arm,17,-1,1);ctx.stroke();
 // neck and face
 ctx.fillStyle="#b96a4d";ctx.fillRect(-15,-103,30,35);
 ctx.fillStyle="#c97a59";ctx.strokeStyle="#54273f";ctx.lineWidth=7;ctx.beginPath();ctx.ellipse(0,-145,58,68,0,0,Math.PI*2);ctx.fill();ctx.stroke();
 // hair
 ctx.fillStyle="#21162c";ctx.beginPath();ctx.arc(0,-172,61,Math.PI,Math.PI*2);ctx.quadraticCurveTo(70,-205,55,-140);ctx.quadraticCurveTo(25,-168,0,-160);ctx.quadraticCurveTo(-55,-135,-58,-150);ctx.closePath();ctx.fill();
 // hair bun and head scarf
 ctx.beginPath();ctx.arc(-35,-207,29,0,Math.PI*2);ctx.fill();
 ctx.fillStyle="#e83e77";ctx.beginPath();ctx.moveTo(-57,-192);ctx.quadraticCurveTo(0,-240,62,-188);ctx.lineTo(52,-170);ctx.quadraticCurveTo(0,-205,-51,-172);ctx.closePath();ctx.fill();ctx.strokeStyle="#ffc46e";ctx.lineWidth=5;ctx.stroke();
 // eyes and smile
 ctx.fillStyle="#24152b";ctx.beginPath();ctx.arc(-20,-145,5,0,Math.PI*2);ctx.arc(20,-145,5,0,Math.PI*2);ctx.fill();
 ctx.strokeStyle="#6d3041";ctx.lineWidth=4;ctx.beginPath();ctx.arc(0,-126,15,.15,Math.PI-.15);ctx.stroke();
 // earrings
 glow(-58,-130,8,"#ffd36d");glow(58,-130,8,"#ffd36d");
 // skirt patterns
 ctx.strokeStyle="#ffd16f";ctx.lineWidth=5;ctx.beginPath();ctx.moveTo(-110,185);ctx.quadraticCurveTo(0,215,110,185);ctx.stroke();
 for(let i=-2;i<=2;i++)glow(i*35,244,5,"#ffe3a1",.9);
 ctx.restore();
}

function drawDecor(t,scene,energy){
 // hanging festoon
 ctx.strokeStyle="#d9a16e";ctx.lineWidth=5;ctx.beginPath();ctx.moveTo(0,80);ctx.quadraticCurveTo(960,230,1920,80);ctx.stroke();
 for(let i=0;i<25;i++){let x=i*80,y=85+Math.sin(i/24*Math.PI)*145;glow(x,y+24,9,"#ffbd62",.8);ctx.fillStyle="#e5a16b";ctx.fillRect(x-2,y,4,22)}
 // floating diyas
 for(let i=0;i<7;i++){let x=(i*310+t*24)%2100-90,y=600+Math.sin(t*1.1+i)*90;ctx.fillStyle="#ffb45e";ctx.beginPath();ctx.ellipse(x,y,28,10,0,0,Math.PI*2);ctx.fill();glow(x,y-12,8,"#ffe59c",.7)}
 // occasional sparkle bursts
 for(let i=0;i<3;i++){let x=220+i*730+Math.sin(t+i)*35,y=320+Math.cos(t*.7+i)*55,r=16+energy*28;ctx.save();ctx.translate(x,y);ctx.strokeStyle="#ffe2a0";ctx.lineWidth=4;for(let k=0;k<8;k++){ctx.rotate(Math.PI/4);ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(r,0);ctx.stroke()}ctx.restore()}
}

function draw(t){
 const scene=clamp(Math.floor(t/SCENE_LEN),0,SCENE_COUNT-1);
 const local=(t-scene*SCENE_LEN)/SCENE_LEN;
 let energy=0;
 if(analyser&&freqData){analyser.getByteFrequencyData(freqData);energy=freqData.reduce((a,b)=>a+b,0)/(freqData.length*255)}
 ctx.save();
 // subtle scene-to-scene camera drift
 const zoom=1.015+Math.sin(local*Math.PI)*.012;
 ctx.translate(W/2,H/2);ctx.scale(zoom,zoom);ctx.translate(-W/2+Math.sin(t*.17)*8,-H/2+Math.cos(t*.13)*5);
 drawSky(t,scene,energy);drawCity(t,scene,energy);
 // occasional soft decorative halo
 if(scene%5===0){ctx.strokeStyle="#e7a2a9";ctx.globalAlpha=.4;ctx.lineWidth=5;ctx.setLineDash([5,18]);ctx.beginPath();ctx.arc(960,560,260+Math.sin(t)*10,0,Math.PI*2);ctx.stroke();ctx.setLineDash([]);ctx.globalAlpha=1}
 drawDecor(t,scene,energy);drawGirl(t,scene,energy);
 // Scene-specific atmospheric overlays, not lyric text
 if(scene%4===1){ctx.globalAlpha=.22;ctx.fillStyle="#ff9f9f";ctx.beginPath();ctx.ellipse(960,650,600,110,0,0,Math.PI*2);ctx.fill();ctx.globalAlpha=1}
 // transition fade at boundaries
 const edge=Math.min(local,1-local),fade=clamp((.055-edge)/.055,0,1);
 if(fade>0){ctx.fillStyle=`rgba(12,7,25,${fade*.5})`;ctx.fillRect(0,0,W,H)}
 ctx.restore();
 sceneLabel.textContent=`Scene ${String(scene+1).padStart(2,"0")} · ${scenes[scene][0]}`;
 timeLabel.textContent=`${fmt(t)} / ${fmt(DURATION)}`;
 updateActive(scene);
}
function fmt(s){let m=Math.floor(s/60),sec=(s%60).toFixed(1).padStart(4,"0");return `${String(m).padStart(2,"0")}:${sec}`}
function updateActive(n){[...sceneList.children].forEach((el,i)=>el.classList.toggle("active",i===n))}
scenes.forEach((s,i)=>{let el=document.createElement("div");el.className="scene-chip";el.textContent=`${String(i+1).padStart(2,"0")} · ${s[0]}`;el.title=`${fmt(i*SCENE_LEN)}–${fmt(Math.min(DURATION,(i+1)*SCENE_LEN))}\n${s[1]}`;el.addEventListener("click",()=>{audio.currentTime=i*SCENE_LEN;draw(audio.currentTime)});sceneList.appendChild(el)});
function tick(){draw(audio.currentTime||0);if(!audio.paused)raf=requestAnimationFrame(tick)}
function setupAudio(){if(audioCtx)return;audioCtx=new(window.AudioContext||window.webkitAudioContext)();analyser=audioCtx.createAnalyser();analyser.fftSize=256;freqData=new Uint8Array(analyser.frequencyBinCount);source=audioCtx.createMediaElementSource(audio);source.connect(analyser);analyser.connect(audioCtx.destination)}
document.getElementById("playBtn").onclick=async()=>{setupAudio();if(audioCtx.state==="suspended")await audioCtx.resume();await audio.play();cancelAnimationFrame(raf);tick()};
document.getElementById("pauseBtn").onclick=()=>audio.pause();
document.getElementById("restartBtn").onclick=()=>{audio.currentTime=0;draw(0);audio.play().then(()=>tick()).catch(()=>{})};
audio.addEventListener("pause",()=>cancelAnimationFrame(raf));
audio.addEventListener("ended",()=>{cancelAnimationFrame(raf);draw(DURATION)});
audio.addEventListener("timeupdate",()=>{seek.value=audio.currentTime});
seek.max=DURATION;seek.addEventListener("input",()=>{audio.currentTime=Number(seek.value);draw(audio.currentTime)});
document.getElementById("audioFile").addEventListener("change",e=>{const f=e.target.files[0];if(f){audio.pause();audio.src=URL.createObjectURL(f);audio.load();audio.currentTime=0;draw(0)}});
const recordBtn=document.getElementById("recordBtn");
recordBtn.onclick=async()=>{
 if(recording){if(recorder&&recorder.state!=="inactive")recorder.stop();audio.pause();return}
 setupAudio();if(audioCtx.state==="suspended")await audioCtx.resume();
 if(!("MediaRecorder"in window)){alert("MediaRecorder is not supported in this browser.");return}
 const stream=canvas.captureStream(30);
 const audioStream=audio.captureStream?audio.captureStream():null;
 if(audioStream)audioStream.getAudioTracks().forEach(track=>stream.addTrack(track));
 chunks=[];let mime=MediaRecorder.isTypeSupported("video/webm;codecs=vp9,opus")?"video/webm;codecs=vp9,opus":"video/webm";
 recorder=new MediaRecorder(stream,{mimeType:mime});recorder.ondataavailable=e=>{if(e.data.size)chunks.push(e.data)};
 recorder.onstop=()=>{const blob=new Blob(chunks,{type:"video/webm"});const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;a.download="kesariya-animation.webm";a.click();setTimeout(()=>URL.revokeObjectURL(url),30000);recording=false;recordBtn.textContent="Record WebM"};
 recorder.start();recording=true;recordBtn.textContent="Stop recording";await audio.play();tick();
};
draw(0);
})();