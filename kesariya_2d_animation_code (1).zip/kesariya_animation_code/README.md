# Kesariya 2D Animation Code Project

This is a **code project**, not a pre-rendered video. It creates a 1920×1080, 16:9, 30 FPS Canvas animation preview and synchronises it to the supplied audio.

## Files
- `index.html` — preview interface and controls
- `styles.css` — interface styling
- `script.js` — procedural 2D character, city, lighting, particles, scene changes and audio sync
- `assets/kesariya_audio.wav` — supplied audio
- `assets/style_reference.mp4` — supplied visual reference (for your own comparison)

## Run on Windows
1. Extract the ZIP.
2. Open the folder in VS Code, or simply double-click `index.html` to open it in Chrome/Edge.
3. Press **Play**. If the browser blocks audio, click Play again.
4. Use the timeline slider or scene tiles to jump around.
5. You can load a different audio file with **Choose audio**.

## Recording
The **Record WebM** button captures the canvas and audio in real time. Let the song play to the end, then stop the recording. Browser support varies; Chrome or Edge is recommended.

To convert the resulting WebM to MP4 with FFmpeg:
```bash
ffmpeg -i kesariya-animation.webm -c:v libx264 -pix_fmt yuv420p -r 30 -c:a aac -b:a 192k -movflags +faststart kesariya-animation.mp4
```

## Customising
- Edit the `scenes` array near the top of `script.js` to change scene names and notes.
- `SCENE_COUNT` controls the number of scene slots; currently 32 across 268.167 seconds.
- `drawGirl()` controls the character appearance and dance motion.
- `drawCity()`, `drawSky()` and `drawDecor()` control the environment.
- The project is original vector artwork inspired by the supplied reference's broad visual language (night-purple sky, warm moonlight, colourful Indian rooftops, a girl in a bright traditional outfit). It does not reproduce every frame of the reference video.
